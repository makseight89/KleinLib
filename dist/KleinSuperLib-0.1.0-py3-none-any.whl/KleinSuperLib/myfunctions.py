def KLEIN():
    print("KLEEEEEIN")